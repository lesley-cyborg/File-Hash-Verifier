import os
import hashlib
import tkinter as tk
from tkinter import filedialog, messagebox

def calculate_sha256(file_path):
    sha256 = hashlib.sha256()
    try:
        # Open the file in binary mode
        with open(file_path, "rb") as f:
            # Read the file in chunks to avoid using too much memory
            for chunk in iter(lambda: f.read(4096), b""):
                sha256.update(chunk)
        # Return the hexadecimal digest of the hash
        return sha256.hexdigest()
    except Exception as e:
        return f"An error occurred: {str(e)}"

def browse_file():
    file_path = filedialog.askopenfilename()
    if file_path:
        file_entry.delete(0, tk.END)
        file_entry.insert(0, file_path)

def verify_hash():
    file_path = file_entry.get()
    original_hash = hash_entry.get().strip()

    if not file_path or not os.path.isfile(file_path):
        messagebox.showwarning("Error", "Please select a valid file.")
        return

    calculated_hash = calculate_sha256(file_path)
    result_text = f" 📄 File: {file_path}\n 🔢 SHA256: {calculated_hash}"
    
    if original_hash:
        if calculated_hash.lower() == original_hash.lower():
            result_text += "\n✅ Hash matchs! File valid."
        else:
            result_text += "\n❌ Hash does not match! File may be corrupted or altered."
    else:
        result_text += "\n⚠️ No original hash provided for comparison."
        
    result_display.config(state=tk.NORMAL)
    result_display.delete(1.0, tk.END)
    result_display.insert(tk.END, result_text)
    result_display.config(state=tk.DISABLED)

def save_report():
    report = result_display.get("1.0", tk.END).strip()
    if not report:
        messagebox.showwarning("Error", "No report to save.")
        return
    
    save_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                                filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
    if save_path:
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(report)
            messagebox.showinfo("Report Saved", f"Report saved to: \n{save_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save report: {str(e)}")
                
# GUI setup
root = tk.Tk()
root.title("🔐 File Hash Verifier")
root.geometry("600x450") 
root.resizable(False, False)  # Allow resizing vertically and horizointally i u want
#root.configure(bg="#3f0404")  # Set background color
#root.iconbitmap("icon.ico")  # Ensure you have an icon file named 'icon.ico'               
root.configure(bg="#1e1e1e")   

font_label = ("Arial", 12)
font_entry = ("Arial", 12)
font_button = ("Arial", 12, "bold")
file_label = tk.Label(root, text="📂 Select File:", font=font_label, bg="#1e1e1e", fg="#ffffff")
file_label.pack(pady=10)

#file_entry = tk.Entry(root, width=50, font=font_entry)             
# File input field
tk.Label(root, text="File Path:", font=font_label, bg="#1e1e1e", fg="#ffffff").pack(pady=5)
file_frame = tk.Frame(root, bg="#1e1e1e")
file_frame.pack(pady=5)
file_entry = tk.Entry(file_frame, width=50, font=font_entry)
file_entry.pack(side=tk.LEFT, padx=5, pady=5)
browse_button = tk.Button(file_frame, text="Browse", command=browse_file, font=font_button, bg="#007bff", fg="#ffffff")
browse_button.pack(side=tk.LEFT, padx=5, pady=5)

# Original hash input
tk.Label(root, text="Original SHA256 Hash (optional):", bg="#1e1e1e", fg="white", font=font_label).pack(pady=5)
hash_entry = tk.Entry(root, width=60, font=font_entry)
hash_entry.pack(pady=5)

# Buttons
tk.Button(root, text="Verify", font=font_label, command=verify_hash).pack(pady=10)
tk.Button(root, text="Save Report", font=font_label, command=lambda: save_report()).pack(pady=5)

# Result output
result_display = tk.Text(root, width=70, height=12, wrap="word", font=("Courier", 9), bg="#2a2a2a", fg="lime", state='disabled')
result_display.pack(pady=10)

root.mainloop()