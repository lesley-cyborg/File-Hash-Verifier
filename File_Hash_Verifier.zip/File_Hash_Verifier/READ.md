# 🧪 File Hash Verifier

A simple Python GUI tool built with Tkinter that computes and verifies SHA256 hashes of files. Useful for checking file integrity and detecting tampering.

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![GUI](https://img.shields.io/badge/GUI-Tkinter-informational)
![Security](https://img.shields.io/badge/Feature-Hash%20Validation-green)

---

## 🔍 Features

- ✅ Calculate SHA256 hash of any file
- 🔒 Compare with an original hash to verify integrity
- 💻 GUI interface using Tkinter
- 💾 Save verification results to `.txt` report files
- 🌑 Dark-themed and beginner-friendly interface
- 📂 Supports drag-and-drop and native file dialog

---

## 🖥️ Demo

### 📸 Screenshots

| Interface | Verification Result |
|----------|---------------------|
| ![Main GUI](screenshots/gui_main.png) | ![Hash Match](screenshots/verified_hash.png) |

---

## 🚀 Getting Started

### 📦 Requirements

- Python 3.10+
- `tkinter` (usually included with Python)
- Works on Windows/Linux/macOS

### ▶️ Running the App

```bash
python file_hash_verifier.py
